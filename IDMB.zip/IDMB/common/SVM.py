from sklearn import tree, svm, datasets, neural_network
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.multiclass import OneVsRestClassifier
from sklearn.neural_network import MLPClassifier
import numpy as np
from sklearn.metrics import classification_report
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from xgboost.sklearn import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from lightgbm import LGBMClassifier
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc
from sklearn.svm import SVC

def SVM(MB, data, target):
    data = np.array(data)
    number = np.shape(data)
    X = np.zeros((number[0], len(MB)))
    print(np.shape(X))
    for i in range(len(MB)):
        X[:, i] = np.array(data[:, MB[i]])
    y = data[:, target]

    kf = KFold(n_splits=10, shuffle=True)
    accuracy = np.zeros((10, 3))
    precision = np.zeros((10, 3))
    recall = np.zeros((10, 3))
    f1_score = np.zeros((10, 3))

    i = 0
    for train_index, test_index in kf.split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]

        y_test = y_test.astype(int)
        clf1 = XGBClassifier()
        clf1.fit(X_train, y_train)
        y_predict1 = clf1.predict(X_test)

        accuracy[i, 0] = classification_report(y_test, y_predict1, output_dict=True)['accuracy']
        y_predict1 = y_predict1.astype(int)
        recall[i, 0] = classification_report(y_test, y_predict1, output_dict=True)['1']['recall']
        s = classification_report(y_test, y_predict1, output_dict=True)['weighted avg']
        precision[i, 0] = s['precision']
        f1_score[i, 0] = s['f1-score']
        
	clf2 = SVC(kernel="rbf")
        clf2.fit(X_train, y_train)
        y_predict2 = clf2.predict(X_test)
        accuracy[i, 1] = classification_report(y_test, y_predict2, output_dict=True)['accuracy']
        y_predict2 = y_predict2.astype(int)
        recall[i, 1] = classification_report(y_test, y_predict2, output_dict=True)['1']['recall']
        s = classification_report(y_test, y_predict2, output_dict=True)['weighted avg']
        precision[i, 1] = s['precision']
        f1_score[i, 1] = s['f1-score']

        clf3 = MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=10000)
        clf3.fit(X_train, y_train)
        y_predict3 = clf3.predict(X_test)
        accuracy[i, 2] = classification_report(y_test, y_predict3, output_dict=True)['accuracy']
        y_predict3 = y_predict3.astype(int)
        recall[i, 2] = classification_report(y_test, y_predict3, output_dict=True)['1']['recall']
        s = classification_report(y_test, y_predict3, output_dict=True)['weighted avg']
        precision[i, 2] = s['precision']
        f1_score[i, 2] = s['f1-score']

        i = i + 1

    accuracy_mean = np.mean(accuracy, 0)
    precision_mean = np.mean(precision, 0)
    recall_mean = np.mean(recall, 0)
    f1_score_mean = np.mean(f1_score, 0)
    return accuracy_mean, precision_mean, recall_mean, f1_score_mean

