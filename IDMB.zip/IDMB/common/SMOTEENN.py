import pandas as pd
from collections import Counter
from imblearn.combine import SMOTEENN

def SMOTEENN(df):

    [a, b] = df.shape
    print([a, b])
    arr = df.values
    X = arr[0:a+1, 0:(b-1)]
    y = arr[0:a+1, b-1]


    print('Original dataset shape %s' % Counter(y))

    sm = SMOTEENN(random_state=0)
    X_res, y_res = sm.fit_resample(X, y)
    print('Resampled dataset shape %s' % Counter(y_res))


    data_x = pd.DataFrame(X_res)
    data_y = pd.DataFrame(y_res)
    result = pd.concat([data_x, data_y], axis=1)
    array = result.to_numpy()

    return array