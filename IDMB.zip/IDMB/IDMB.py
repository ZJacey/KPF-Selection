"""
 Time: 2024/11/23

 File: IDMB.py

 Main paper: An Interleaved-Deletion Markov Boundary Discovery Algorithm for Robust Causal Feature Selection in Manufacturing Systems

Author and programmer: Jiaqi Zhang, Liangxing Shi, Mengmeng Zhu, Zhen He

 e-Mail: jiaqizhang99@tju.edu.cn
 """

import numpy as np
from common.condition_independence_test import cond_indep_test
from common.subsets import subsets
from common.SVM import SVM
from common.SMOTEENN import SMOTEENN
import time


def IDMB(data, target, alaph, is_discrete=True):
    ci_number = 0
    number, kVar = np.shape(data)
    CPC = []
    max_k = 3
    TMP = [i for i in range(kVar) if i != target]
    sepset = [[] for i in range(kVar)]
    CSPT = [[] for i in range(kVar)]
    variDepSet = []
    SP = [[] for i in range(kVar)]
    pval_CSPT = []
    for x in TMP:
        ci_number += 1
        pval_f, dep_f = cond_indep_test(data, target, x, [], is_discrete)
        if pval_f > alaph:
            sepset[x] = []
        else:
            variDepSet.append([x, dep_f]) 

    variDepSet = sorted(variDepSet, key=lambda x: x[1], reverse=True)
    A_0 = []
    for variIndex in variDepSet:
        A = variIndex[0]
        Slength = len(CPC)
        if Slength > max_k:
            Slength = 3
        breakFlag = False
        for j in range(Slength + 1):
            count = j
            ZSubsets = subsets(CPC, j)
            for Z in ZSubsets:
                # print("Z is: " + str(Z))
                ci_number += 1
                # print("Z is: " + str(Z))
                # print("convari is: " + str(convari))
                pval_TAZ, dep_TAZ = cond_indep_test(
                    data, target, A, Z, is_discrete)
                if pval_TAZ > alaph:
                    sepset[A] = Z
                    breakFlag = True
                    break
            if breakFlag:
                break

        if not breakFlag:
            CPC_ReA = CPC.copy()
            B_index = len(CPC_ReA)
            CPC.append(A)
            breakF = False

            while B_index > 0:
                B_index -= 1
                B = CPC_ReA[B_index]
                flag1 = False

                conditionSet = [i for i in CPC_ReA if i != B]
                Clength = len(conditionSet)
                if Clength > max_k:
                    Clength = max_k
                for w in range(Clength + 1):
                    CSubsets = subsets(conditionSet, w)

                    for Z in CSubsets:
                        if A_0 in Z or A_0 == []:
                            ci_number += 1
                            pval_TBZ, dep_TBZ = cond_indep_test(
                                data, target, B, Z, is_discrete)
                            # print("pval_TBZ: " + str(pval_TBZ))
                            if pval_TBZ >= alaph:
                                if B in CPC:
                                    CPC.remove(B)
                                CSPT[B] = []
                                sepset[B] = Z
                                flag1 = True
                        else:
                            continue
                    if flag1:
                        break
            A_0 = A
            CSPT[A] = []

            for C in range(kVar):
                # if C == target or C in CPC:
                if C == target:
                    continue
                conditionSet = [i for i in sepset[C]]
                conditionSet.append(A)
                conditionSet = list(set(conditionSet))

                ci_number += 1
                pval_CAT, dep_TBZ = cond_indep_test(
                    data, target, C, conditionSet, is_discrete)
                if pval_CAT <= alaph:
                    CSPT[A].append(C)
                    pval_CSPT.append([A, C, dep_TBZ])

    PC = []
    variDepSet_CPC = []
    A_0 = []

    for i in CPC:
        for variIndex in variDepSet:
            if i == variIndex[0]:
                variDepSet_CPC.append([i, variIndex[1]])
        variDepSet_CPC = sorted(variDepSet_CPC, key=lambda x: x[1], reverse=True)


    for i in variDepSet_CPC:
        new_PC = i[0]
        PC.append(new_PC)

        x_index = len(PC)
        A_breakFlag = False
        while x_index >= 0:
            x_index -= 1
            x = PC[x_index]
            flag2 = False
            ZZALLsubsets = [i for i in PC if i != x] 
            Zlength = len(ZZALLsubsets)
            if Zlength > max_k:
                Zlength = max_k
            for w in range(Zlength + 1):
                Zzsubsets = subsets(ZZALLsubsets, w)
                for Z in Zzsubsets:
                    if A_0 in Z or A_0 == []:
                        if x == new_PC:
                            ZconditionSet = list(set(CSPT[x]).union(set(Z)))
                        else:
                            ZconditionSet = list(set(SP[x]).union(set(Z)))
                        ZconditionSet = Z
                        Zcon = []
                        for i in Z:
                            for j in SP[i]:
                                Zcon.append(j)
                        ZconditionSet = list(set(Zcon).union(set(Z)))
                        ci_number += 1
                        pval, _ = cond_indep_test(
                            data, target, x, ZconditionSet, is_discrete)

                        if pval >= alaph:
                            PC.remove(x)

                            CPC.remove(x)
                            CSPT[x] = []
                            for e in pval_CSPT:
                                if e[0] == x:
                                    pval_CSPT.remove(e)
                            flag2 = True

                            if x == i:
                                A_breakFlag = True
                            break
                    else:
                        continue
                if flag2:
                    break
            if A_breakFlag:
                break
        A_0 = new_PC

        if new_PC in PC:
            pval_CSPT_i = []
            for q in pval_CSPT:
                if q[0] == new_PC:
                    pval_CSPT_i.append([q[1], q[2]])
            pval_CSPT_i = sorted(pval_CSPT_i, key=lambda x: x[1],
                               reverse=True)
            SP[new_PC] = []

            for pCSPT_index in pval_CSPT_i:
                E = pCSPT_index[0]
                SP[new_PC].append(E)
                index_spa = len(SP[new_PC])
                breakflag_spa = False
                while index_spa >= 0:
                    index_spa -= 1
                    x = SP[new_PC][index_spa]
                    breakFlag = False
                    ZAllSubsets = list(set(PC).union(
                        set(SP[new_PC])))

                    ZAllSubsets.remove(x)
                    ZAllSubsets.remove(new_PC)
                    Zalength = len(ZAllSubsets)
                    if Zalength > max_k:
                        Zalength = max_k
                    for j in range(Zalength + 1):
                        ZaSubsets = subsets(ZAllSubsets, j)
                        for Z in ZaSubsets:
                            Z = [i for i in Z]
                            Z.append(new_PC)
                            ci_number += 1
                            pval_TXZ, _ = cond_indep_test(  
                                data, target, x, Z, is_discrete)

                            if pval_TXZ > alaph:
                                SP[new_PC].remove(x)

                                breakFlag = True
                                if x == E:
                                    breakflag_spa = True
                                break
                        if breakFlag:
                            break
                    if breakflag_spa:
                        break
    spouseT = [j for i in PC for j in SP[i]]
    MB = list(set(PC).union(set(spouseT)))
    return MB, ci_number

import pandas as pd
file_path = ("dataset.csv")
for r in range(1, 2):
    data = pd.read_csv(file_path)
    print("the file read")
    data = SMOTEENN(data)

    target = 38
    alaph = 0.05
    n = 10
    t = np.zeros(n)
    accuracy = np.zeros((n, 3))
    precision = np.zeros((n, 3))
    recall = np.zeros((n, 3))
    f1_score = np.zeros((n, 3))
    ci_number = np.zeros(n)
    for i in range(n):
        start_time = time.process_time()
        MB, ci_number0 = IDMB(data, target, alaph, is_discrete=False)
        accuracy0, precision0, recall0, f1_score0 = SVM(MB, data, target)
        end_time = time.process_time()
        print(str(r))
        print("MBs is: " + str(MB))
        print(len(MB))
        accuracy[i, :] = accuracy0
        precision[i, :] = precision0
        recall[i, :] = recall0
        f1_score[i, :] = f1_score0
        ci_number[i] = ci_number0
        t[i] = end_time - start_time
    accuracy_mean = np.mean(accuracy, 0)
    precision_mean = np.mean(precision, 0)
    recall_mean = np.mean(recall, 0)
    f1_score_mean = np.mean(f1_score, 0)
    ci_number_mean = np.mean(ci_number, 0)
    t_mean = np.mean(t, 0)

